# 🐝 Пчелен Рай — ASP.NET MVC + Entity Framework 6 + SQL Server

## Структура на проекта

```
HoneyShop/
├── Controllers/
│   ├── HomeController.cs          ← Начало, За нас, Контакти
│   └── ProductsController.cs      ← Продукти (чете от БД чрез DbContext)
│
├── Models/
│   ├── Category.cs                ← Модел: категория (Id, Name)
│   └── Product.cs                 ← Модел: продукт (+ CategoryId FK)
│
├── Data/
│   └── ApplicationDbContext.cs    ← DbContext: DbSet<Product>, DbSet<Category>
│
├── Migrations/
│   ├── Configuration.cs           ← Seed данни (6 продукта, 3 категории)
│   └── 202401010000000_InitialCreate.cs  ← Генерирана от Add-Migration
│
├── Views/
│   ├── Shared/_Layout.cshtml
│   ├── Home/   Index, About, Contact
│   └── Products/  Index, Details
│
├── Content/css/Site.css
├── Web.config                     ← Connection String към LocalDB
└── packages.config                ← NuGet: EntityFramework 6.4.4, MVC 5.2.7
```

---

## Стъпки за стартиране

### 1. Отвори проекта
- Разархивирай ZIP файла
- Visual Studio → File → Open → Project/Solution → избери `HoneyShop.csproj`

### 2. Възстанови NuGet пакети
- Дясно върху Solution → Restore NuGet Packages
- (или Visual Studio го прави автоматично)

### 3. Приложи миграциите (създай базата данни)
- Tools → NuGet Package Manager → Package Manager Console
- Въведи:
```
Update-Database
```
- Това създава базата `PchelenRajDb` в SQL Server LocalDB
- и добавя 3 категории + 6 продукта автоматично

### 4. Стартирай
- Натисни **F5**
- Браузърът се отваря на http://localhost:{порт}/

---

## Релационна схема

```
Categories                    Products
──────────────────            ─────────────────────────────
Id   (PK, int)  ←─────────── CategoryId  (FK, int)
Name (nvarchar)               Id          (PK, int)
                              Name        (nvarchar)
                              Description (nvarchar)
                              Price       (decimal)
                              Weight      (nvarchar)
                              IsAvailable (bit)
```

**Връзка: One-to-Many**
Една категория → много продукти
Един продукт → точно една категория

---

## Команди за миграции (справка)

| Команда | Какво прави |
|---------|------------|
| `Add-Migration InitialCreate` | Генерира файл с описание на промените |
| `Update-Database` | Прилага миграциите към SQL Server |
| `Update-Database -TargetMigration:0` | Връща всички миграции (rollback) |
