namespace HoneyShop.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using HoneyShop.Data;
    using HoneyShop.Models;

    // Този клас управлява миграциите.
    // Методът Seed() добавя начални данни при всяко Update-Database.
    internal sealed class Configuration : DbMigrationsConfiguration<ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "HoneyShop.Data.ApplicationDbContext";
        }

        // Seed() се изпълнява след всяка миграция.
        // AddOrUpdate() означава: добави ако не съществува, обнови ако съществува.
        protected override void Seed(ApplicationDbContext context)
        {
            // ── 1. Добавяме категории ──────────────────────
            context.Categories.AddOrUpdate(
                c => c.Name,  // уникален ключ за проверка
                new Category { Id = 1, Name = "Монофлорен мед" },
                new Category { Id = 2, Name = "Горски мед" },
                new Category { Id = 3, Name = "Цветен мед" }
            );

            context.SaveChanges(); // записваме категориите преди продуктите

            // ── 2. Добавяме продукти ───────────────────────
            context.Products.AddOrUpdate(
                p => p.Name,
                new Product
                {
                    Id = 1,
                    Name        = "Акациев мед",
                    Description = "Нежен бял мед с деликатен аромат. Не кристализира дълго. Идеален за бебета над 1 год.",
                    Price       = 12.90m,
                    Weight      = "500г",
                    ImageClass  = "acacia",
                    Emoji       = "🍯",
                    Badge       = "Хит",
                    IsAvailable = true,
                    CategoryId  = 1   // Монофлорен мед
                },
                new Product
                {
                    Id = 2,
                    Name        = "Липов мед",
                    Description = "Ароматен мед с успокояващо действие. Перфектен за вечерен чай.",
                    Price       = 10.50m,
                    Weight      = "500г",
                    ImageClass  = "linden",
                    Emoji       = "🌿",
                    Badge       = "Любимец",
                    IsAvailable = true,
                    CategoryId  = 1   // Монофлорен мед
                },
                new Product
                {
                    Id = 3,
                    Name        = "Планински мед",
                    Description = "Тъмен богат мед от дива планинска флора — мащерка, жълт кантарион, горска малина.",
                    Price       = 15.00m,
                    Weight      = "500г",
                    ImageClass  = "mountain",
                    Emoji       = "⛰️",
                    Badge       = "Премиум",
                    IsAvailable = true,
                    CategoryId  = 3   // Цветен мед
                },
                new Product
                {
                    Id = 4,
                    Name        = "Слънчогледов мед",
                    Description = "Жълт, бързо кристализиращ мед с наситен вкус и висока концентрация на глюкоза.",
                    Price       = 8.50m,
                    Weight      = "500г",
                    ImageClass  = "sunflower",
                    Emoji       = "🌻",
                    Badge       = "Нов",
                    IsAvailable = true,
                    CategoryId  = 1   // Монофлорен мед
                },
                new Product
                {
                    Id = 5,
                    Name        = "Горски мед",
                    Description = "Тъмен мед от иглолистни гори. Богат на минерали и ензими.",
                    Price       = 18.00m,
                    Weight      = "500г",
                    ImageClass  = "forest",
                    Emoji       = "🌲",
                    Badge       = "Рядък",
                    IsAvailable = true,
                    CategoryId  = 2   // Горски мед
                },
                new Product
                {
                    Id = 6,
                    Name        = "Кориандров мед",
                    Description = "Рядък и ароматен мед с леко пикантен послевкус. Събиран в ограничени количества.",
                    Price       = 16.50m,
                    Weight      = "500г",
                    ImageClass  = "coriander",
                    Emoji       = "🌸",
                    Badge       = "Лимитиран",
                    IsAvailable = false,
                    CategoryId  = 3   // Цветен мед
                }
            );

            context.SaveChanges();
        }
    }
}
