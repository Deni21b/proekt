namespace HoneyShop.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    // Това е миграцията, генерирана от командата:
    // Add-Migration InitialCreate
    //
    // Тя описва каква SQL структура трябва да се създаде.
    // Update-Database я изпълнява и създава таблиците в SQL Server.
    public partial class InitialCreate : DbMigration
    {
        // Up() се изпълнява при Update-Database - СЪЗДАВА таблиците
        public override void Up()
        {
            // ── Създаване на таблица Category ─────────────
            CreateTable(
                "dbo.Category",
                c => new
                {
                    Id   = c.Int(nullable: false, identity: true),  // Primary Key, auto-increment
                    Name = c.String(nullable: false, maxLength: 100),
                })
                .PrimaryKey(t => t.Id);

            // ── Създаване на таблица Product ──────────────
            CreateTable(
                "dbo.Product",
                c => new
                {
                    Id          = c.Int(nullable: false, identity: true), // Primary Key
                    Name        = c.String(nullable: false, maxLength: 200),
                    Description = c.String(maxLength: 1000),
                    Price       = c.Decimal(nullable: false, precision: 18, scale: 2),
                    Weight      = c.String(maxLength: 50),
                    ImageClass  = c.String(maxLength: 50),
                    Emoji       = c.String(maxLength: 10),
                    Badge       = c.String(maxLength: 50),
                    IsAvailable = c.Boolean(nullable: false),
                    CategoryId  = c.Int(nullable: false), // Foreign Key
                })
                .PrimaryKey(t => t.Id)
                // ── Дефиниране на Foreign Key ──────────────
                // Product.CategoryId -> Category.Id
                // Това е връзката One-to-Many
                .ForeignKey("dbo.Category", t => t.CategoryId)
                .Index(t => t.CategoryId); // индекс за по-бързо търсене
        }

        // Down() се изпълнява при rollback - ИЗТРИВА таблиците
        public override void Down()
        {
            DropIndex("dbo.Product", new[] { "CategoryId" });
            DropForeignKey("dbo.Product", "CategoryId", "dbo.Category");
            DropTable("dbo.Product");
            DropTable("dbo.Category");
        }
    }
}
