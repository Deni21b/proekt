using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using HoneyShop.Models;

namespace HoneyShop.Data
{
    // ApplicationDbContext е "вратата" към базата данни.
    // Наследява DbContext от Entity Framework.
    // Всяко DbSet<T> = една таблица в SQL Server.
    public class ApplicationDbContext : DbContext
    {
        // Подаваме connection string по име от Web.config
        public ApplicationDbContext()
            : base("name=HoneyShopConnection")
        {
        }

        // ── ТАБЛИЦИ ──────────────────────────────────
        // DbSet<Category> => таблица Categories
        public DbSet<Category> Categories { get; set; }

        // DbSet<Product> => таблица Products
        public DbSet<Product> Products { get; set; }

        // ── КОНФИГУРАЦИЯ НА МОДЕЛА ────────────────────
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Изключваме автоматичното множествено число на имената
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            // ── Връзка Category -> Products (One-to-Many) ──
            // Една категория има много продукти
            // Един продукт има точно една категория
            modelBuilder.Entity<Product>()
                .HasRequired(p => p.Category)
                .WithMany(c => c.Products)
                .HasForeignKey(p => p.CategoryId)
                .WillCascadeOnDelete(false);

            // ── Seed Data: начални данни ─────────────────
            // Seed се прави в Migration-а, не тук (виж Migrations/Configuration.cs)
        }

        // Статичен метод за лесно създаване на инстанция
        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }
    }
}
