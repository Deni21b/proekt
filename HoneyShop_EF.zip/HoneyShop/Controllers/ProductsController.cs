using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using HoneyShop.Data;
using HoneyShop.Models;

namespace HoneyShop.Controllers
{
    // Контролер за продуктите - използва реална база данни чрез DbContext
    public class ProductsController : Controller
    {
        // DbContext - "вратата" към базата данни
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: /Products
        // Include("Category") = JOIN - зарежда категорията на всеки продукт
        public ActionResult Index()
        {
            ViewBag.Title = "Нашите продукти";

            var products = db.Products
                             .Include(p => p.Category)
                             .OrderBy(p => p.CategoryId)
                             .ToList();

            // Подаваме и списъка с категории за филтриране
            ViewBag.Categories = db.Categories.ToList();

            return View(products);
        }

        // GET: /Products/ByCategory/1 - продукти по категория
        public ActionResult ByCategory(int id)
        {
            var category = db.Categories.Find(id);
            if (category == null)
                return HttpNotFound();

            ViewBag.Title      = "Категория: " + category.Name;
            ViewBag.Categories = db.Categories.ToList();

            var products = db.Products
                             .Include(p => p.Category)
                             .Where(p => p.CategoryId == id)
                             .ToList();

            return View("Index", products);
        }

        // GET: /Products/Details/5
        public ActionResult Details(int id)
        {
            var product = db.Products
                            .Include(p => p.Category)
                            .FirstOrDefault(p => p.Id == id);

            if (product == null)
                return HttpNotFound();

            ViewBag.Title = product.Name;
            return View(product);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
                db.Dispose();
            base.Dispose(disposing);
        }
    }
}
