using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using HoneyShop.Data;
using HoneyShop.Models;

namespace HoneyShop.Controllers
{
    public class HomeController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: / - Начална страница, показва 3 продукта от базата
        public ActionResult Index()
        {
            ViewBag.Title = "Начало";

            // Взимаме първите 3 налични продукта с техните категории
            var featuredProducts = db.Products
                                     .Include(p => p.Category)
                                     .Where(p => p.IsAvailable)
                                     .Take(3)
                                     .ToList();

            return View(featuredProducts);
        }

        // GET: /Home/About
        public ActionResult About()
        {
            ViewBag.Title = "За нас";
            return View();
        }

        // GET: /Home/Contact
        public ActionResult Contact()
        {
            ViewBag.Title = "Контакти";
            return View();
        }

        // POST: /Home/Contact
        [HttpPost]
        public ActionResult Contact(string name, string email, string message)
        {
            ViewBag.Title   = "Контакти";
            ViewBag.Message = "Благодарим! Съобщението е изпратено успешно.";
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
                db.Dispose();
            base.Dispose(disposing);
        }
    }
}
