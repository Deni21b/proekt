using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HoneyShop.Models
{
    // Модел за категория на меда
    // Една категория може да има МНОГО продукти (One-to-Many)
    public class Category
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Категория")]
        public string Name { get; set; }

        // Навигационна колекция — всички продукти от тази категория
        public virtual ICollection<Product> Products { get; set; }

        public Category()
        {
            Products = new List<Product>();
        }
    }
}
