using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HoneyShop.Models
{
    // Модел за продукт (пчелен мед)
    // Всеки продукт принадлежи на ЕДНА категория (Many-to-One)
    public class Product
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Наименование")]
        public string Name { get; set; }

        [Display(Name = "Описание")]
        public string Description { get; set; }

        [Required]
        [Display(Name = "Цена (лв.)")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        [Display(Name = "Тегло")]
        public string Weight { get; set; }

        [Display(Name = "CSS клас")]
        public string ImageClass { get; set; }

        [Display(Name = "Икона")]
        public string Emoji { get; set; }

        [Display(Name = "Бадж")]
        public string Badge { get; set; }

        [Display(Name = "Наличен")]
        public bool IsAvailable { get; set; }

        // FOREIGN KEY към Category
        // Това е връзката "много продукти -> една категория"
        [Required]
        [Display(Name = "Категория")]
        public int CategoryId { get; set; }

        // Навигационно свойство - зарежда обекта Category автоматично
        [ForeignKey("CategoryId")]
        public virtual Category Category { get; set; }
    }
}
